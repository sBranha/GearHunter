<?php
declare(strict_types=1);
require __DIR__.'/github-sync.php';
// Unified current addon. Historical explicit-version URLs retain the legacy download behavior below.
$ghnSlug = (string)($_GET['addon'] ?? '');
$ghnVersion = (string)($_GET['version'] ?? '');
if (in_array($ghnSlug, ['gear-hunter', 'maphub', 'navigator'], true)
    && ($ghnVersion === '' || $ghnVersion === '0.4.7')) {
  if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') { http_response_code(405); exit('GET required'); }
  try {
    $old = gh_addon('gear-hunter');
    if ($old && isset($old['id'])) {
      $q = gh_db()->prepare('INSERT INTO downloads(addon_id,version,day,clicks) VALUES(?,?,?,1) ON CONFLICT(addon_id,version,day) DO UPDATE SET clicks=clicks+1');
      $q->execute([(int)$old['id'], '0.4.7', gmdate('Y-m-d')]);
    }
  } catch (Throwable $e) { error_log('Navigator download counter: '.$e->getMessage()); }
  header('Cache-Control: no-store');
  header('Location: https://github.com/sBranha/GearHunter/releases/download/navigator-v0.4.7/GearHunterNavigator-v0.4.7.zip', true, 302);
  exit;
}

try{
 if($_SERVER['REQUEST_METHOD']!=='GET'){http_response_code(405);exit('GET required');}
 gh_auto_sync();$addon=gh_addon(gh_text($_GET['addon']??'',80));if(!$addon){http_response_code(404);exit('Unknown addon');}
 $ver=gh_text($_GET['version']??$addon['current_version'],45);
 $s=gh_db()->prepare('SELECT * FROM releases WHERE addon_id=? AND version=?');$s->execute([$addon['id'],$ver]);$release=$s->fetch();if(!$release){http_response_code(404);exit('Unknown release');}
 $remote=(string)$release['url'];$local=(string)$release['file_name'];
 if($remote){
  // Count the click on YOUR website, then send browser to the actual Github ZIP asset.
  $prefix='https://github.com/'.$addon['repo'].'/releases/download/';
  if(!gh_valid_repo((string)$addon['repo'])||!str_starts_with($remote,$prefix))throw new RuntimeException('Untrusted GitHub release URL');
 }elseif($local===''||!is_file(gh_file($local))){http_response_code(404);exit('Addon ZIP has not yet been published on GitHub.');}
 gh_db()->prepare('INSERT INTO downloads(addon_id,version,day,clicks) VALUES(?,?,?,1) ON CONFLICT(addon_id,version,day) DO UPDATE SET clicks=clicks+1')->execute([$addon['id'],$ver,gmdate('Y-m-d')]);
 if($remote){header('Cache-Control: no-store');header('Location: '.$remote,true,302);exit;}
 // Legacy locally staged releases can still be downloaded until moved to GitHub.
 $path=gh_file($local);set_time_limit(0);header('Content-Type: application/zip');header('Content-Disposition: attachment; filename="'.basename($path).'"');header('Content-Length: '.filesize($path));header('Cache-Control: private, no-store');$f=fopen($path,'rb');while(!feof($f)&&!connection_aborted()){echo fread($f,1024*1024);flush();}fclose($f);
}catch(Throwable $e){error_log('Addon download: '.$e->getMessage());http_response_code(503);echo 'Download temporarily unavailable.';}
