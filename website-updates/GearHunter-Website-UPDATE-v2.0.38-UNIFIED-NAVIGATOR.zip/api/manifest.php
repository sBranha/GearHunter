<?php
declare(strict_types=1);
require __DIR__.'/shared.php';
gh_json(200,['ok'=>true,'manifestVersion'=>1,'updated'=>gmdate('c'),
 'addons'=>['gear-hunter'=>[
   'name'=>'Gear Hunter Navigator','folder'=>'GearHunterNavigator','version'=>'0.4.7',
   'notes'=>'Unified gear, leveling, quests, reputation, collections, mounts, rares, treasures and navigation.',
   'download'=>'https://gearhunter.net/api/download.php?addon=gear-hunter',
   'site'=>'https://gearhunter.net/api/navigator-page.php',
   'sha256'=>'99413e629b4b4cdf321070ebf56cd4ca694ec0369e606f20fb69a3c9d403c573','verification'=>'sha256-available',
   'sha256_url'=>'https://github.com/sBranha/GearHunter/releases/download/navigator-v0.4.7/GearHunterNavigator-v0.4.7.zip.sha256'
 ]]]);
