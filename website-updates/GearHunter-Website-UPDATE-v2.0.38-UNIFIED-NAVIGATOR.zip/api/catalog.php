<?php
declare(strict_types=1);
require __DIR__.'/shared.php';
try {
 $clicks=0;
 try {
  $a=gh_addon('gear-hunter');
  if($a){ $s=gh_db()->prepare('SELECT COALESCE(SUM(clicks),0) FROM downloads WHERE addon_id=? AND version=?'); $s->execute([(int)$a['id'],'0.4.7']);$clicks=(int)$s->fetchColumn(); }
 } catch(Throwable $ignored){}
 gh_json(200,[
  'ok'=>true,'source'=>'Official Gear Hunter Navigator GitHub release','updated'=>gmdate('c'),
  'addons'=>[[
   'slug'=>'gear-hunter','name'=>'Gear Hunter Navigator',
   'description'=>'Unified gear upgrades, class leveling, quests, reputation, mounts, toys, rares, treasures and adventure planning.',
   'version'=>'0.4.7','folder'=>'GearHunterNavigator',
   'download'=>'/api/download.php?addon=gear-hunter',
   'stats'=>['website_download_clicks'=>$clicks,'github_asset_downloads'=>null],
   'releases'=>[[
     'version'=>'0.4.7', 'published_at'=>'2026-10-21T01:12:39Z',
     'notes'=>'One unified addon: Gear Hunter, MapHub locations and Navigator. Level-aware upgrades, class guides, quests, faction reputation, owned mounts/toys, custom map icons and ornate Midnight frame.',
     'url'=>'https://github.com/sBranha/GearHunter/releases/download/navigator-v0.4.7/GearHunterNavigator-v0.4.7.zip', 'github_url'=>'https://github.com/sBranha/GearHunter/releases/tag/navigator-v0.4.7',
     'sha256'=>'99413e629b4b4cdf321070ebf56cd4ca694ec0369e606f20fb69a3c9d403c573','asset_bytes'=>72404764
   ]]
  ]]
 ]);
} catch(Throwable $e){error_log('Navigator public catalog: '.$e->getMessage());gh_json(503,['ok'=>false,'error'=>'Catalog unavailable']);}
