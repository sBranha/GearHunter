GEARHUNTER.NET WEBSITE UPDATE v2.0.38 — UNIFIED NAVIGATOR

Official addon: Gear Hunter Navigator v0.4.7
GitHub: https://github.com/sBranha/GearHunter/releases/tag/navigator-v0.4.7
Current download: https://github.com/sBranha/GearHunter/releases/download/navigator-v0.4.7/GearHunterNavigator-v0.4.7.zip

INSTALL VIA YOUR EXISTING SITE ADMIN UPDATER:
  https://gearhunter.net/admin/updater.php
  Upload this complete WEBSITE UPDATE ZIP, review and click Install Update.
  Rollback is available through the same updater.

WHAT CHANGES:
- Replaces Gear Hunter and MapHub public current-download cards with one Navigator listing.
- Uses the verified v0.4.7 ZIP on your existing GearHunter GitHub repository.
- Preserves website download-click counting (recorded under existing Gear Hunter addon ID).
- Adds /api/navigator-page.php with exact feature descriptions and correct /ghnav installation instructions.
- Updates homepage featured release, metadata, current-version catalog and optional Companion manifest.
- Leaves the Online Armory, videos, admin panel, support inbox and SQLite data alone.
- Prior standalone GitHub releases remain archived, not deleted.

IMPORTANT: This does not install automatically. It is a site updater package, not a WoW addon ZIP.
No complete World of Warcraft character or item database is claimed. Known rare pins do not confirm live spawns.
