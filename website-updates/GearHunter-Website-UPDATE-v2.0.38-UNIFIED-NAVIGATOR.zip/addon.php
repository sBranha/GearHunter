<?php
declare(strict_types=1);
header('Location: /api/navigator-page.php',true,302);
header('Cache-Control: no-store');
exit;
