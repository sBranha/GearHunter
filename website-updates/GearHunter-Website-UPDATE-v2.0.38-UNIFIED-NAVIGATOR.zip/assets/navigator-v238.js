/* GearHunter.net v2.0.38: feature/launch consistency for the unified Navigator. */
(()=>{'use strict';
const version='0.4.7';
function refresh(){
 document.title='Gear Hunter Navigator — Download & Support | v'+version;
 for(const n of document.querySelectorAll('[data-addon-version]'))n.textContent='v'+version;
 for(const n of document.querySelectorAll('[data-version-plain]'))n.textContent=version;
 for(const n of document.querySelectorAll('[data-addon-size]'))n.textContent='72.4 MB';
 for(const n of document.querySelectorAll('a[data-addon-file], .download-secure a[data-addon-file]'))n.href='api/download.php?addon=gear-hunter';
 const checksum=document.querySelector('#downloadSha a'); if(checksum){checksum.href='https://github.com/sBranha/GearHunter/releases/download/navigator-v'+version+'/GearHunterNavigator-v'+version+'.zip.sha256';checksum.textContent='Verify Gear Hunter Navigator v'+version+' SHA-256';}
 const notice=document.querySelector('#github-live-counts');if(notice && /Gear Hunter|GitHub ZIP/.test(notice.textContent)){notice.textContent='Gear Hunter Navigator v'+version+' is available from the official GitHub release; this site tracks clicks on its download link.';}
 const hero=document.querySelector('.hero-description');if(hero)hero.textContent='Upgrade your gear, follow class leveling and quests, track mounts and reputation, and find known rares and treasures—all inside one World of Warcraft addon.';
 const dl=document.querySelector('.download-info > p');if(dl)dl.textContent="One addon: Gear Hunter equipment tools, MapHub discoveries and Navigator's leveling, quest, mount, reputation and collection guides.";
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',refresh);else refresh();
window.addEventListener('load',refresh,{once:true});
})();
