// Keep in sync with GearHunter/SupportCenter.lua on each addon release.
window.GH_RELEASES = [
  {"version":"0.4.7","title":"Gear Hunter Navigator — Unified Addon","changes":["The original Gear Hunter equipment tools and Midnight artwork are integrated with MapHub rare/treasure map records and Navigator's class leveling, quests, reputations, mounts and toys.","Gear recommendations include a default five-level eligibility range and an optional ten-level range.","Maps use the approved eight category icons for rares, treasures, bosses, secrets, quests, vendors and flight paths."],"how":"Install only the GearHunterNavigator addon folder, keep WTF, restart WoW and type /ghnav. Older separate releases remain in the GitHub archive."},

  {
    "version": "0.11.7", "title": "Official GearHunter.net Companion integration",
    "changes": ["Optional Windows update notifier through GearHubBridge, while Gear Hunter remains fully independent.","Added /ghwebsite to show the official download address.","Anonymous installation and load reporting requires explicit Companion opt-in."],
    "how": "Install the optional Companion from gearhunter.net, choose privacy settings, and close WoW while it prepares GearHubBridge. Open WoW or /reload for the update notice. Type /ghwebsite to find the official site."
  },
  {
    "version": "0.11.6",
    "title": "In-game Support Center",
    "changes": [
      "The top-right ? now opens its own Midnight-styled help window.",
      "Added What's New, Quick Start, Feature Guides, Troubleshooting, Commands, and About pages.",
      "Added a bug-reporting page with copyable diagnostics and a release-note NEW marker."
    ],
    "how": "Click ? at the top of Gear Hunter or type /gh support. Open What's New to clear the NEW marker. Use REPORT ISSUE for information on troubleshooting and sharing diagnostic details."
  },
  {
    "version": "0.11.5",
    "title": "Farm Session Tracker",
    "changes": [
      "Track successful boss encounters and your own loot events across saved farming sessions."
    ],
    "how": "Open Gear Search > Boss Loot > Farm Session Tracker, or type /gh session. Press Start Session before farming and Finish Session afterward."
  },
  {
    "version": "0.11.4",
    "title": "Boss and Instance Favorites",
    "changes": [
      "Save favorite raids, dungeons and bosses. Filter the Boss Loot browser to favorites only."
    ],
    "how": "Open Gear Search > Boss Loot and select Save Instance or Save Boss. Use /gh favorites to reopen bookmarks."
  },
  {
    "version": "0.11.3",
    "title": "Collection Dashboard",
    "changes": [
      "Added a combined overview for tracked gear, appearance wishlists, alts and saved lockouts."
    ],
    "how": "Open Hunt List > Dashboard, or type /gh collection."
  },
  {
    "version": "0.11.2",
    "title": "Gear Upgrade Planner",
    "changes": [
      "Set upgrade priorities and view known upgrade tracks; inspect exact costs while at an item upgrade NPC."
    ],
    "how": "Open My Gear > Upgrade Planner, or /gh plan. Select an item at a Blizzard upgrade NPC and refresh costs."
  },
  {
    "version": "0.11.1",
    "title": "Boss Loot Hunter",
    "changes": [
      "Browse indexed raid/dungeon bosses and their loot, with hunt and map actions."
    ],
    "how": "Open Gear Search > Boss Loot, or /gh bosses. Index the Adventure Guide to expand results."
  },
  {
    "version": "0.11.0",
    "title": "Transmog Layout Repair",
    "changes": [
      "Removed overlapping shared controls from the Transmog view and improved empty results guidance."
    ],
    "how": "Open /gh mog. Choose a category and index appearances to populate the list."
  },
  {
    "version": "0.10.9",
    "title": "Alt Tracker",
    "changes": [
      "Added saved gear and boss-lockout snapshots for characters you have played."
    ],
    "how": "Open Hunt List > Alt Tracker, or /gh alts. Switch characters to refresh their snapshots."
  },
  {
    "version": "0.10.8",
    "title": "Weekly Farm Tracker",
    "changes": [
      "Added lockout and defeated-boss information reported by WoW."
    ],
    "how": "Open Hunt List > Weekly Lockouts, or /gh weekly. Refresh lockouts for current data."
  },
  {
    "version": "0.10.7",
    "title": "Smart Upgrade Recommendations",
    "changes": [
      "Rank upgrades by item-level gain and estimated source accessibility."
    ],
    "how": "Open Smart Picks or /gh smart. Scan the Journal first; choose a ranking mode and filters."
  },
  {
    "version": "0.10.6",
    "title": "Farm Route Planner",
    "changes": [
      "Group unfinished Hunt List items by known farming destination and organize your stops."
    ],
    "how": "Open Hunt List > Plan Farm Route, or /gh route. Choose a stop and use Show Entrance or Show Boss when available."
  },
  {
    "version": "0.10.5",
    "title": "Hunt List",
    "changes": [
      "Save desired equipment, mark items completed, and track progress."
    ],
    "how": "Open Hunt List or /gh hunt. Add items from Gear Search or paste an item link."
  },
  {
    "version": "0.10.4",
    "title": "Transmog Hunter",
    "changes": [
      "Browse missing/collected appearances and keep an appearance wishlist."
    ],
    "how": "Open Transmog or /gh mog and choose Index All Categories to build your collection browser."
  },
  {
    "version": "0.10.3",
    "title": "Gear Source Expansion",
    "changes": [
      "Capture observed vendor equipment, quest rewards and profession recipes."
    ],
    "how": "Open a merchant, quest or profession window and use /gh capture. Additional sources are saved when seen in game."
  },
  {
    "version": "0.10.2",
    "title": "Map Source Fixes",
    "changes": [
      "Separated known instance entrances from boss-floor navigation and improved source matching."
    ],
    "how": "Select an indexed item and use Show Entrance or Show Boss. Unknown coordinates stay unavailable."
  },
  {
    "version": "0.10.1",
    "title": "Gear Search",
    "changes": [
      "Search a local gear index by name, item ID or pasted link, including Adventure Guide loot."
    ],
    "how": "Open Gear Search or /gh search. Index All Dungeons / Raids for broader historical loot."
  }
];
