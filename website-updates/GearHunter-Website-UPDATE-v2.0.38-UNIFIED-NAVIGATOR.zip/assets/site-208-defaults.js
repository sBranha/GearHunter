'use strict';
(function(){
 const prior=window.GH_SITE||{};
 window.GH_SITE=Object.freeze(Object.assign({},prior,{websiteVersion:'2.0.38',addonVersion:'0.4.7',addonSizeMB:'72.4',addonSHA256:'99413e629b4b4cdf321070ebf56cd4ca694ec0369e606f20fb69a3c9d403c573'}));
})();
