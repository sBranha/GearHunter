/* One place to edit the website release, download location and video links.
   Keep this in sync when publishing a NEW addon; addon releases are managed from the website admin dashboard. */
window.GH_SITE = Object.freeze({
  websiteVersion: '2.0.38',
  addonVersion: '0.4.7',
  addonFile: 'api/download.php?addon=gear-hunter',
  addonSizeMB: '72.4',
  addonSHA256: '99413e629b4b4cdf321070ebf56cd4ca694ec0369e606f20fb69a3c9d403c573',
  contact: '',
  venmo: 'https://venmo.com/u/theaminoexchange',
  videos: [
    {id:'install',title:'Install & Launch',file:'assets/videos/install-and-launch.mp4',kind:'illustrated guide',time:'00:20',description:'See exactly where the addon folder goes and how to open the interface.'},
    {id:'upgrades',title:'Scan & Find Upgrades',file:'assets/videos/scan-and-upgrades.mp4',kind:'illustrated guide',time:'00:20',description:'Learn the journal scan, gear selection, and source inspection flow.'},
    {id:'hunt',title:'Build Your Farm Route',file:'assets/videos/hunt-list-and-route.mp4',kind:'illustrated guide',time:'00:20',description:'Save targets to Hunt List and plan your next farming run.'}
  ],
  /* Paste real https://www.youtube.com/watch?v=... links here when you record in-game tutorials. */
  youtube: []
});
