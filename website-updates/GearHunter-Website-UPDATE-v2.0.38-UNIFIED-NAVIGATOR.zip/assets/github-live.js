/* GearHunter.net v2.0.10 — cached GitHub data, with reliable offline defaults. */
(function(){
 'use strict';
 const fallback='0.4.7';
 const $=s=>document.querySelector(s);
 const $$=s=>document.querySelectorAll(s);
 const isVersion=s=>/^\d+\.\d+\.\d+$/.test(String(s));
 const compare=(a,b)=>{const x=a.split('.').map(Number),y=b.split('.').map(Number);for(let i=0;i<3;i++){if(x[i]!==y[i])return x[i]-y[i];}return 0;};
 const verifiedBase='https://github.com/sBranha/GearHunter/releases/download/';
 function update(version,gear){
  if(!isVersion(version))return;
  window.GH_ACTIVE_VERSION=version;
  $$('[data-addon-version]').forEach(n=>n.textContent='v'+version);
  $$('[data-version-plain]').forEach(n=>n.textContent=version);
  const eyebrow=$('.hero .eyebrow');if(eyebrow&&eyebrow.lastChild&&eyebrow.lastChild.nodeType===3)eyebrow.lastChild.textContent=' v'+version;
  const med=$('.latest-medal strong');if(med)med.textContent=version;
  const big=$('.big-version');if(big)big.textContent='v'+version;
  const footer=$('.footer-bottom p:last-child');if(footer)footer.textContent='Gear Hunter Navigator v'+version+' · Website v2.0.38';
  const meta=$('meta[name="description"]');if(meta)meta.content='Download Gear Hunter Navigator v'+version+', browse WoW addon guides, release notes, troubleshooting and support.';
  document.title='Gear Hunter Navigator — Download, Help & Support | v'+version;
  const issue=$('#issueVersion');
  // Do not overwrite a visitor's version if they have entered a different version.
  if(issue&&!issue.dataset.manualVersion){issue.value=version;issue.defaultValue=version;}
  const checksum=$('#downloadSha');
  if(checksum){
   const a=document.createElement('a');
   a.href=verifiedBase+'navigator-v'+version+'/GearHunterNavigator-v'+version+'.zip.sha256';
   a.textContent='View official SHA-256 checksum for v'+version;
   a.rel='noopener noreferrer';a.target='_blank';checksum.replaceChildren(a);
  }
  const size=$('[data-addon-size]');
  const current=(gear?.releases||[]).find(r=>r.version===version);
  if(size)size.textContent=Number(current?.asset_bytes)>0?(Number(current.asset_bytes)/1000000).toFixed(1)+' MB':(version===fallback?'72.4 MB':'See GitHub release');
  if(gear&&current&&String(current.notes||'').trim()){
   const title=$('.release-lead h3'),description=$('.release-lead p');
   if(title)title.textContent='Latest release: v'+version;
   if(description)description.textContent=String(current.notes).replace(/[#*_]+/g,'').trim().slice(0,450);
   // New releases after the bundled release history appear with complete notes.
   const timeline=$('#releaseTimeline');
   if(timeline&&!Array.from(timeline.querySelectorAll('.release-version')).some(n=>n.textContent.trim()==='v'+version)){
    const d=document.createElement('details');d.className='release';d.open=true;d.dataset.dynamicRelease=version;
    const s=document.createElement('summary');s.textContent='v'+version+' — Official Release';
    const body=document.createElement('p');body.style.whiteSpace='pre-wrap';body.style.padding='14px 18px';body.textContent=String(current.notes).slice(0,6000);
    d.append(s,body);timeline.prepend(d);
   }
  }
  if(gear){
   const download=$('.download-secure');let info=$('#github-live-counts');
   if(download&&!info){info=document.createElement('p');info.id='github-live-counts';info.style.cssText='margin-top:12px;color:#eed5a3;font-size:.91rem;';download.insertAdjacentElement('afterend',info);}
   if(info){const stats=gear.stats||{},num=n=>(Number(n)||0).toLocaleString('en-US');
    info.textContent='Website Navigator download clicks: '+num(stats.website_download_clicks)+' · GitHub release download totals are shown on GitHub.';}
  }
 }
 async function refresh(){
  update(fallback,null);
  const issue=$('#issueVersion');if(issue)issue.addEventListener('input',()=>{issue.dataset.manualVersion='true';});
  try{
   const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),7000);
   let response;try{response=await fetch('/api/catalog.php',{cache:'no-store',signal:controller.signal});}finally{clearTimeout(timeout);}
   if(!response.ok)throw Error('Catalog unavailable');
   const data=await response.json();if(data?.ok!==true||!Array.isArray(data.addons))throw Error('Invalid catalog');
   const gear=data.addons.find(a=>a.slug==='gear-hunter');
   if(!gear||!isVersion(gear.version))throw Error('Version missing');
   // If the database sync has not caught up yet, keep the known published release.
   const version=compare(gear.version,fallback)>=0?gear.version:fallback;
   update(version,version===gear.version?gear:null);
  }catch(_){
   // The static fallback remains usable even if SQLite or GitHub is unreachable.
  }
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',refresh);else refresh();
})();
